﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterController : MonoBehaviour
{

    private Rigidbody2D rb2D;
    public Animator anim;
    public float thrust = 10.0f;
    

    // Start is called before the first frame update
    void Start()
    {
        rb2D = gameObject.AddComponent<Rigidbody2D>();
        rb2D.freezeRotation = true;
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(1)) //Upon right mouse click, the character would have force applied vertically to the y-axis and jump up 
        {
            rb2D.AddForce(transform.up * thrust, ForceMode2D.Impulse);
            anim.SetBool("IsJumping", true); // when pressed, the jump animtion will trigger
            Debug.Log("Right mouse click");

        }


    }

    private void OnCollisionEnter2D(Collision2D collision) // code needed to check the character in contact with ground and to trigger run animation 
    {
        if (collision.gameObject.tag == "g")
        {
            Debug.Log("touchign the ground");
            anim.SetTrigger("run");
            anim.SetBool("IsJumping", false);
            
        }
    }




}
