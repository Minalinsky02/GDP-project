﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject object1;
    public GameObject object2;
    public GameObject object3;
    public GameObject object4;
    public GameObject object5;
    public GameObject object6;

    public int maxItems = 2;
    public int items = 0;

    public float horizontalMin = 20f;
    public float horizontalMax = 25f;
    public float verticalMin = 0f;
    public float verticalMax = 5f;

    private Vector2 playerPosition;

    // Start is called before the first frame update
    void Start()
    {
        playerPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if(items < maxItems)
        {
            items++;
            Vector2 randomPosition = playerPosition + new Vector2(Random.Range(horizontalMin, horizontalMax), Random.Range(verticalMin, verticalMax));
            int x = Random.Range(1, 6);
            if(x == 1)
            {

                Instantiate(object1, randomPosition, Quaternion.identity);
            }

            else if (x == 2)
            {

                Instantiate(object2, randomPosition, Quaternion.identity);
            }

            else if (x == 3)
            {

                Instantiate(object3, randomPosition, Quaternion.identity);
            }

            else if (x == 4)
            {

                Instantiate(object4, randomPosition, Quaternion.identity);
            }

            else if (x == 5)
            {

                Instantiate(object5, randomPosition, Quaternion.identity);
            }

            else if (x == 6)
            {

                Instantiate(object6, randomPosition, Quaternion.identity);
            }
        }
    }
}
