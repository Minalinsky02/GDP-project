﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public static int scorePoint = 0;
    Text score;

    // Start is called before the first frame update
    void Start()
    {
        score = GetComponent<Text>();
    }

    private void Update()
    {
        score.text = "Money: " + scorePoint;

    }
    // Update is called once per frame
    void AddScore()
    {
        scorePoint += 10;
    }
    void LoseMoney()
    {
        scorePoint -= 10;
    }

}
