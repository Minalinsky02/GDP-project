﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuCut : MonoBehaviour
{
    public void gameStart()
    {
        SceneManager.LoadScene("Loading Screen");
        Debug.Log("Button Is Pressed");
    }
    public void Restart()
    {
        SceneManager.LoadScene("Game");
        Debug.Log("Restart is pressed");
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Quit Game");
    }

  
  
}
