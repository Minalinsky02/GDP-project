﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Despawner : MonoBehaviour
{

    public Spawner Spawner;

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Money")
        {
            Destroy(col.gameObject);
            Spawner.items--;
        }

        if (col.gameObject.tag == "Enemy")
        {
            Destroy(col.gameObject);
            Spawner.items--;
        }
    }
}
