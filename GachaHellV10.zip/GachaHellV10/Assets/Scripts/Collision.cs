﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Collision : MonoBehaviour
{

    public ScoreManager Score;
    private int money = 0;
    public static int scorePoint = 0;
  


    private void OnTriggerEnter2D(Collider2D col)
    {
        scorePoint = 0;
        if (col.gameObject.tag == "Money")
        {
            ScoreManager.scorePoint += 10;
            Destroy(col.gameObject);
            Debug.Log("Crash into money");
        }

        if (col.gameObject.tag == "Enemy" )
        {
            
            ScoreManager.scorePoint -= 10;
            Debug.Log("Oh No Enemy");
        }

        if (col.gameObject.tag == "Enemy" && money == 0)
        {
            SceneManager.LoadScene("gameove");
            Debug.Log("Oh No Enemy");
        }
    }

   

}
