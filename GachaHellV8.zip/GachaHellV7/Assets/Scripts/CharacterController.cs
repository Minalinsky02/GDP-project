﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterController : MonoBehaviour
{

    private Rigidbody2D rb2D;
    private Animation animate;
    public Animator anim;
    public float thrust = 10.0f;
    private bool isGrouneded = true;

    // Start is called before the first frame update
    void Start()
    {
        rb2D = gameObject.AddComponent<Rigidbody2D>();
        rb2D.freezeRotation = true;
        //animate.Play("Running");
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            rb2D.AddForce(transform.up * thrust, ForceMode2D.Impulse);
            anim.SetBool("IsJumping", true);
            Debug.Log("Right mouse click");

        }


    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "g")
        {
            Debug.Log("touchign the ground");
            anim.SetTrigger("run");
            anim.SetBool("IsJumping", false);
            
        }
    }



    private void OnCollisionExit2D(Collision2D collision)
    {

    }

}
