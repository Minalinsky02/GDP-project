﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collision : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Money")
        {
            Debug.Log("Player has scored!");
            Destroy(col.gameObject);
        }

        if (col.gameObject.tag == "Enemy")
        {
            Debug.Log("Player has died!");
        }
    }
}
